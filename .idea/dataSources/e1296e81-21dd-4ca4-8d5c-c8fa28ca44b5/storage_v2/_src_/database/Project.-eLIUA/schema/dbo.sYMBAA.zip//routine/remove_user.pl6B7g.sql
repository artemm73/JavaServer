CREATE PROCEDURE remove_user(@login nvarchar(50))
AS
BEGIN
  delete from Users where users.Login = @login;
END;
go

