CREATE PROCEDURE check_user(@username varchar(50), @result BIT OUT)
AS
BEGIN
  IF ( (select distinct count(*) from users where @username = users.Login) = 1)
    SET @result = 1;
  ELSE
    SET @result = 0;
END;
go

