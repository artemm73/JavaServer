CREATE PROCEDURE insert_data(@t_start FLOAT, @t_end FLOAT)
AS
BEGIN
	INSERT INTO StartData([Start], [End]) VALUES (@t_start, @t_end);
END;
go

