CREATE PROCEDURE insert_user(@login nVARCHAR(50), @password nVARCHAR(50), @email nVARCHAR(50), @fName nVARCHAR(50))
AS
BEGIN
  INSERT INTO Users([Login], FirstName, Email, [Password]) VALUES (@login, @fName, @email, @password);
END;
go

