CREATE PROCEDURE remove_data(@t_start FLOAT, @t_end FLOAT)
AS
BEGIN
  delete from StartData where StartData.[Start] = @t_start AND StartData.[End] = @t_end;
END;
go

