
CREATE PROCEDURE check_user_password(@username nvarchar(50), @password varchar(50), @result bit OUTPUT)
AS
BEGIN
	IF ((SELECT DISTINCT count(*) FROM Users
			WHERE (@username = Users.Login) AND (@password = Users.Password)) 
		= 1) 

		SET @result = 1;
	ELSE
		SET @result = 0;
END;
go

